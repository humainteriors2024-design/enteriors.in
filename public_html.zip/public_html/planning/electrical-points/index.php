<?php
/* CLUSTER PAGE — /planning/electrical-points/
   Migrated on 2026-10-04 from "Pages - old/electrical point guide.html" (4963 words). Edit freely.
   Images: /assets/pages/planning/electrical-points/   (hero.jpg = main image) */
$page = [
  'type'         => 'article',
  'title'        => 'The Complete Electrical Planning Guide for Home Interiors',
  'seo_title'    => 'Electrical Points Planning for Home Interiors',
  'description'  => 'Plan electrical points room by room: sockets, switches, lights, AC, geyser, kitchen appliances, smart home, CCTV and inverter circuits, before walls close.',
  'lede'         => 'Plan electrical points room by room: sockets, switches, lights, AC, geyser, kitchen appliances, smart home, CCTV and inverter circuits, before walls close.',
  'hero_alt'     => 'The Complete Electrical Planning Guide for Home Interiors',
  'published'    => '2026-06-15',
  'updated'      => '2026-10-07',
];
require $_SERVER['DOCUMENT_ROOT'] . '/includes/head.php';
?>
<ul>
  <li>Electrical Planning 2025 India Guide</li>
  <li>25 min read</li>
  <li>Updated June 2025</li>
  <li>Zero Rework Guide</li>
</ul>
<h2>Why Electrical Planning Matters in Interior Design</h2>
<p>Imagine this: your modular kitchen is fully installed, beautiful shutters, granite tops, perfectly aligned tiles. Then your electrician points out there's no power point for the chimney, no dedicated line for the dishwasher, and the hob's ignition wire runs right behind the fitted cabinet. To fix it, <strong>you tear apart a wall, remove two base cabinets, re-tile the backsplash, repaint, and reinstall</strong>. The rework costs more than the original electrical work would have.</p>
<p>This is not a hypothetical. It happens in thousands of Indian homes every year, and it is entirely preventable. <strong>Electrical planning done before interior work begins is the most valuable decision you will make in your renovation.</strong></p>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Scenario</th><th>Planned Electrical</th><th>Unplanned (Rework)</th></tr>
  </thead>
  <tbody>
    <tr><td>Kitchen chimney point missed</td><td>₹ 200 extra conduit during rough-in</td><td>₹ 8,000–18,000 (remove cabinet, tile, replaster)</td></tr>
    <tr><td>AC point in wrong wall</td><td>Reroute conduit before plaster: ₹500</td><td>₹ 5,000–12,000 (chase wall, replaster, repaint)</td></tr>
    <tr><td>False ceiling light position wrong</td><td>Adjust before gypsum: ₹200</td><td>₹ 3,000–6,000 (cut ceiling, patch, repaint)</td></tr>
    <tr><td>No provision for wardrobe light</td><td>One extra conduit: ₹150</td><td>₹ 4,000–9,000 (surface conduit, ugly fix)</td></tr>
    <tr><td>CCTV cable not laid</td><td>Cable in conduit before ceiling: ₹300</td><td>₹ 6,000–14,000 (surface run, cover channels)</td></tr>
  </tbody>
</table>
</div>
<p><strong>The Rule of 10x</strong></p>
<p>Every electrical point that is missed during rough-in phase costs <strong>10 to 50 times more</strong> to add after interior work is complete. The conduit itself costs ₹150–300. The rework to access it after tiling, plastering, painting, and furniture installation costs ₹5,000–₹25,000. Plan once. Execute once.</p>
<h2>When Should Electrical Planning Be Done?</h2>
<p>Electrical planning has three distinct phases in an interior project, and the sequence is non-negotiable. Miss a phase and you compromise the entire project's quality and cost-efficiency.</p>
<p><strong>Phase 1 · Before Civil Work</strong> · Electrical Drawing Approval</p>
<p>Finalise your interior design layout, furniture positions, kitchen layout, and all appliance locations FIRST. Only then create the electrical drawing. This is the planning phase. Every point on paper, nothing on walls yet.</p>
<p><strong>Phase 2 · During Civil/Rough-In</strong> · Conduit Laying &amp; Box Fixing</p>
<p>Electrician chases walls, lays PVC conduits, fixes junction boxes and switchboard boxes, all before plastering. This is when changes cost ₹200, not ₹20,000. The golden window.</p>
<p><strong>Phase 3 · After Plastering, Before Painting</strong> · Wire Pulling &amp; Board Fitting</p>
<p>After plaster cures (14–21 days), wires are pulled through conduits. Switchboards are fitted. Points tested. Then painting, false ceiling, and tile work happens over the clean, concealed wiring.</p>
<p><strong>Phase 4 · After Interior Work</strong> · Final Connections &amp; Testing</p>
<p>After furniture, tiles, false ceiling, and painting are complete: final connections are made, modular switches fitted, lights installed, and the full system tested before handover.</p>
<div class="callout callout--warn"><span class="callout__title">Watch out</span>⚠️ Critical Sequencing Rule<br><br>Your <strong>interior design layout must be finalised BEFORE the electrician begins</strong>. Never start electrical rough-in with a rough sketch or a verbal plan. Insist on a dimensioned electrical drawing approved by both the interior designer and the homeowner before a single wall is chased.</div>
<h2>Electrical Planning Process Step-by-Step</h2>
<h4>Finalise Interior Layout &amp; Furniture Plan</h4>
<p>Confirm sofa position, TV unit location, bed orientation, wardrobe placement, kitchen layout, and all appliance positions. Every furniture piece dictates an electrical point.</p>
<h4>Create Appliance Inventory by Room</h4>
<p>List every appliance, gadget, and light source per room, from the chimney and dishwasher to the phone charger and wardrobe sensor light. Include future-planning items (EV charger, smart home, automation).</p>
<h4>Define Point Locations with Heights</h4>
<p>For each point, define: which wall, horizontal distance from corner, and height from floor level. Standard heights matter: plugs at 300mm, switchboards at 1,200mm, AC at 2,100mm, geyser at 1,800mm.</p>
<h4>Load Calculation &amp; Circuit Planning</h4>
<p>Electrician calculates total load per room. Heavy appliances (AC, geyser, oven, dishwasher) each get a dedicated circuit with independent MCB. Light circuits and power circuits are always separated.</p>
<h4>Main Distribution Board (MDB) Design</h4>
<p>Size the main DB: number of ways, MCB ratings, RCCB protection, separate circuits for inverter and non-inverter loads, surge protection. The DB is the heart of your home's electrical system.</p>
<h4>Electrical Drawing Preparation</h4>
<p>Licensed electrician or electrical consultant prepares a dimensioned single-line diagram and room-wise point layout. Get this drawing approved and signed before rough-in begins.</p>
<h4>Rough-In Execution</h4>
<p>Wall chasing, conduit laying, box fixing, done before plastering. This phase must be supervised. Verify each point against the drawing before walls are closed.</p>
<h4>Wire Pulling &amp; Testing</h4>
<p>After plaster cures, pull wires through conduits. Test continuity of every circuit before the false ceiling and tiles go in.</p>
<h4>Final Fit-Off &amp; Commissioning</h4>
<p>Fit modular switch plates, connect appliances, install lights, test all circuits under load. Commission inverter, automation, and security systems last.</p>
<h2>Understanding Electrical Drawings</h2>
<p>An electrical drawing (also called an electrical layout plan) is a floor-plan scale drawing showing exact locations of every switch, socket, light, fan, appliance point, conduit run, and DB position in your home. It is the blueprint your electrician works from.</p>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Symbol / Element</th><th>What It Means</th><th>Why It Matters</th></tr>
  </thead>
  <tbody>
    <tr><td>⊕ (Circle with cross)</td><td>Ceiling light / downlight point</td><td>Positions false ceiling cutouts</td></tr>
    <tr><td>▷ (Triangle on wall)</td><td>Fan point (ceiling fan outlet)</td><td>Needs structural anchor in ceiling slab</td></tr>
    <tr><td>■ (Filled square)</td><td>Socket / plug point</td><td>Height and position determines furniture clearance</td></tr>
    <tr><td>□ (Open square)</td><td>Switchboard location</td><td>Must not be behind door, furniture, or curtain</td></tr>
    <tr><td>═══</td><td>Conduit run (surface or concealed)</td><td>Routing determines wall chasing scope</td></tr>
    <tr><td>DB</td><td>Distribution Board location</td><td>Central hub: position near entrance, ventilated</td></tr>
    <tr><td>AC</td><td>Split AC outdoor unit conduit</td><td>Wall penetration position for pipe sleeve</td></tr>
    <tr><td>D/L</td><td>Downlight (recessed)</td><td>Height from slab determines false ceiling depth</td></tr>
    <tr><td>EX</td><td>Exhaust fan point</td><td>Position in bathroom/kitchen for cross-ventilation</td></tr>
  </tbody>
</table>
</div>
<p><strong>Standard Electrical Heights (India)</strong></p>
<p>Switchboard: <strong>1,200–1,350mm</strong> from FFL · Socket (power): <strong>300mm</strong> from FFL · Bedside socket: <strong>650–750mm</strong> · TV area socket: <strong>300–400mm</strong> · AC point: <strong>2,000–2,100mm</strong> · Geyser: <strong>1,800mm</strong> · Exhaust fan: <strong>2,100mm</strong> · Kitchen counter socket: <strong>900–1,100mm</strong> (above counter level)</p>
<h2>Room-Wise Electrical Point Planning</h2>
<p>The following sections cover every room in a typical Indian home, with specific point requirements, recommended quantities, heights, special provisions, and common mistakes. This is the core of the guide. Use it as your site reference during planning and execution.</p>
<p><strong>How to Use These Sections</strong></p>
<p>For each room, cross-reference the point list against your interior layout drawing. Mark each point as <strong>Confirmed ✓</strong> or <strong>To Review ?</strong> before signing off on the electrical drawing. Don't let your electrician start rough-in without this review being complete.</p>
<h2>Living Room Electrical Planning</h2>
<p>The living room is the most electrically complex room after the kitchen. It accommodates entertainment, lighting, air conditioning, ambient atmosphere, and increasingly, home automation. Plan generously: under-provisioning here shows every day.</p>
<p><strong>Living Room: 16–22 points</strong></p>
<div class="table-wrap">
<table>
  <thead><tr><th>Point</th><th>Where and why</th></tr></thead>
  <tbody>
    <tr><td>Main Ceiling Light</td><td>Centre or per false ceiling design</td></tr>
    <tr><td>Ceiling Fan Point</td><td>Center of seating area, 2,700mm min headroom</td></tr>
    <tr><td>TV Area Sockets (×4 min)</td><td>TV, set-top box, soundbar, OTT device, all separate</td></tr>
    <tr><td>AC Point (16A dedicated)</td><td>At 2,000–2,100mm, near indoor unit wall</td></tr>
    <tr><td>Sofa-Side Sockets (×2)</td><td>For phone charging, laptop: 300mm from floor</td></tr>
    <tr><td>Profile / Cove Light</td><td>LED strip driver point behind false ceiling cove</td></tr>
    <tr><td>Downlights (×4–8)</td><td>Per false ceiling layout, 600mm from walls</td></tr>
    <tr><td>Feature Wall Light</td><td>Wall washer / accent above sofa or TV wall</td></tr>
    <tr><td>Floor Lamp Socket</td><td>Near reading chair, 300mm floor level</td></tr>
    <tr><td>Speaker / Home Theatre</td><td>Rear speaker cables pre-laid in wall/ceiling</td></tr>
    <tr><td>Network / LAN Point</td><td>Behind TV unit for smart TV / gaming</td></tr>
    <tr><td>Switchboard (Main)</td><td>Near entry, 1,200mm: Fan, Light, AC master switches</td></tr>
  </tbody>
</table>
</div>
<p><strong>Living Room Planning Tip</strong></p>
<p>Always plan <strong>2 separate circuits for the living room</strong>. One for lights/fan and one for all power sockets. This way, if a socket trips an MCB, your lights stay on. Cove/profile lighting must have its own switch (or dimmer) to enable mood lighting independent of main lights.</p>
<h2>TV Unit Electrical Planning</h2>
<p>The TV wall is the most socket-intensive single spot in a home. Poor planning here means a tangle of extension cords behind the unit, a fire hazard and an eyesore. Plan for at least 6–8 sockets in this zone.</p>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Device</th><th>Socket Type</th><th>Height (from FFL)</th><th>Notes</th></tr>
  </thead>
  <tbody>
    <tr><td>LED TV (55"–75")</td><td>5A × 1</td><td>350–400mm</td><td>Centre of TV unit: behind TV</td></tr>
    <tr><td>Set-Top Box / DTH</td><td>5A × 1</td><td>350mm</td><td>Beside TV socket, in cabinet</td></tr>
    <tr><td>Soundbar / AV Receiver</td><td>5A × 1</td><td>350mm</td><td>Near soundbar shelf</td></tr>
    <tr><td>OTT / Gaming Console</td><td>5A × 1</td><td>350mm</td><td>In enclosed cabinet with ventilation</td></tr>
    <tr><td>Router / Modem</td><td>5A × 1</td><td>350mm</td><td>Near LAN point, always keep powered</td></tr>
    <tr><td>Speaker (subwoofer)</td><td>5A × 1</td><td>150mm</td><td>Floor level, beside TV unit</td></tr>
    <tr><td>HDMI / Cable Entry</td><td>Conduit sleeve</td><td>Behind TV</td><td>Blank conduit to route HDMI cables cleanly</td></tr>
    <tr><td>Network / LAN</td><td>CAT6 port</td><td>350mm</td><td>Adjacent to TV socket cluster</td></tr>
    <tr><td>USB Charging Hub</td><td>5A or USB socket</td><td>750mm</td><td>On side panel: accessible while seated</td></tr>
  </tbody>
</table>
</div>
<p><strong>TV Wall Hidden Wire Tip</strong></p>
<p>Route a <strong>75mm diameter blank conduit sleeve from behind the TV mount down to the TV unit cabinet</strong>. This lets you run HDMI cables, power cords, and AV wires invisibly from the wall-mounted TV down to the unit, creating a completely wire-free appearance on the feature wall.</p>
<h2>False Ceiling Lighting Planning</h2>
<p>False ceiling lighting is the single most impactful visual element in an interior, and the most under-planned. Every light type needs its own electrical provision, at the right location, before the gypsum board goes up. There is zero margin for error here.</p>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Light Type</th><th>Power per Unit</th><th>Driver/Connection</th><th>Planning Note</th></tr>
  </thead>
  <tbody>
    <tr><td>LED Downlight (recessed)</td><td>5–12W</td><td>Direct 240V</td><td>Mark centre of each fixture on ceiling plan</td></tr>
    <tr><td>Cove / Profile LED Strip</td><td>9–14W/metre</td><td>LED Driver (12V/24V DC)</td><td>Driver box needs a hidden cavity with 5A socket</td></tr>
    <tr><td>Chandelier / Pendant</td><td>Up to 300W</td><td>Ceiling rose + hook</td><td>Needs structural hook in concrete, not just gypsum</td></tr>
    <tr><td>Spot Track Light</td><td>10–35W per head</td><td>Track rail fed by 1 socket</td><td>Track position is fixed. Plan layout before ceiling</td></tr>
    <tr><td>Linear LED (louvre)</td><td>18–36W per metre</td><td>Direct 240V or driver</td><td>Provision at both ends of linear run</td></tr>
    <tr><td>Up-Lighter (recessed floor)</td><td>3–10W</td><td>Low-voltage, IP54</td><td>Flush in floor: provision before tiling</td></tr>
    <tr><td>Bathroom Exhaust Light</td><td>10–15W</td><td>Integrated unit</td><td>Must be IP44 rated minimum</td></tr>
    <tr><td>Smart Dimmer Provision</td><td>N/A: control</td><td>Live/Neutral/Earth + signal</td><td>Dimmers need neutral wire: plan from DB</td></tr>
  </tbody>
</table>
</div>
<h3>False Ceiling Lighting Zones: Best Practice</h3>
<ul>
  <li><strong>Zone 1: General (Downlights):</strong> Main functional lighting, switched separately</li>
  <li><strong>Zone 2: Cove / Mood (LED Strip):</strong> Warm ambience, on dimmer or separate switch</li>
  <li><strong>Zone 3: Accent (Spots/Pendants):</strong> Feature highlighting, switchable independently</li>
  <li>Never put all ceiling lights on one switch. You lose all lighting control flexibility</li>
  <li>Plan LED driver box locations in false ceiling cavities BEFORE board is installed</li>
  <li>Allow minimum 4-inch (100mm) depth for recessed downlights from bottom of slab</li>
  <li>Cove LED strips need continuous conduit run. Plan the strip length before ordering</li>
</ul>
<h2>Modular Kitchen Electrical Planning</h2>
<p>The kitchen is electrically the most demanding room in any home. It has the highest concentration of high-wattage appliances, the most dedicated circuits, and the most specific height requirements. Every kitchen appliance needs its own provision. No sharing, no extensions.</p>
<p><strong>Modular Kitchen: 18–28 points</strong></p>
<div class="table-wrap">
<table>
  <thead><tr><th>Point</th><th>Where and why</th></tr></thead>
  <tbody>
    <tr><td>Chimney (16A Dedicated)</td><td>Above hob: 1,800mm, hidden in cabinet</td></tr>
    <tr><td>Hob (Electric) (16A)</td><td>Under hob area, only if electric/induction hob</td></tr>
    <tr><td>Microwave (16A Dedicated)</td><td>In tall unit or upper cabinet at 1,500mm</td></tr>
    <tr><td>Oven (16A Dedicated)</td><td>Behind oven unit, at oven height, separate from microwave</td></tr>
    <tr><td>Refrigerator (16A Dedicated)</td><td>Behind fridge: floor level, individual MCB</td></tr>
    <tr><td>Dishwasher (16A Dedicated)</td><td>Under counter near sink, with isolation valve</td></tr>
    <tr><td>Water Purifier (RO)</td><td>Under sink, 300mm, with dedicated 5A socket</td></tr>
    <tr><td>Counter Appliance Sockets (×4–6)</td><td>Above counter at 1,050mm: mixer, toaster, kettle etc.</td></tr>
    <tr><td>Under-Cabinet Light</td><td>LED strip under wall cabinet, shines on counter</td></tr>
    <tr><td>Ceiling Light / Downlight</td><td>2–4 downlights for general kitchen lighting</td></tr>
    <tr><td>Exhaust Fan</td><td>On outer wall at 2,100mm, separate switch</td></tr>
    <tr><td>Washing Machine (if in kitchen)</td><td>16A dedicated, with water inlet/outlet provisions</td></tr>
  </tbody>
</table>
</div>
<div class="callout callout--warn"><span class="callout__title">Watch out</span>⚠️ Kitchen Wiring Rule<br><br>In the modular kitchen, <strong>every appliance above 1000W must have its own dedicated 16A circuit with individual MCB in the DB</strong>. Chimney, microwave, oven, dishwasher, refrigerator, and any electric hob/cooktop must NEVER share a circuit. Sharing causes nuisance trips and fire risk. All kitchen counter sockets must be <strong>above counter level</strong> (min 1,050mm), never below where water can reach.</div>
<h2>Bedroom Electrical Planning</h2>
<p><strong>Bedroom: 12–18 points</strong></p>
<div class="table-wrap">
<table>
  <thead><tr><th>Point</th><th>Where and why</th></tr></thead>
  <tbody>
    <tr><td>Main Ceiling Light</td><td>Center of room or per ceiling design</td></tr>
    <tr><td>Ceiling Fan</td><td>Above bed center: speed regulator switch</td></tr>
    <tr><td>Bedside Socket: Left (×2)</td><td>650–700mm FFL: phone charger + bedside lamp</td></tr>
    <tr><td>Bedside Socket: Right (×2)</td><td>Same height: mirror image of left side</td></tr>
    <tr><td>AC Point (16A Dedicated)</td><td>2,000mm FFL: near indoor unit location</td></tr>
    <tr><td>Dressing Table Socket</td><td>Near mirror: hair dryer, straightener</td></tr>
    <tr><td>Master Switchboard</td><td>Near bed: fan, light, AC control (2-way if at door)</td></tr>
    <tr><td>Cove / Profile Light</td><td>If false ceiling: LED strip driver provision</td></tr>
    <tr><td>Wardrobe Light Socket</td><td>Inside wardrobe: sensor or switch-triggered</td></tr>
    <tr><td>TV Point (if bedroom TV)</td><td>Sockets + HDMI conduit sleeve behind mount</td></tr>
  </tbody>
</table>
</div>
<p><strong>Master Bedroom Special</strong></p>
<p>In the master bedroom, always plan a <strong>2-way switching for the main light</strong>. One switch near the door and one on the bedside switchboard. You should never have to get out of bed to turn off the room light. Similarly, plan a <strong>master cut-off switch</strong> near the bed to switch off all lights/fans with one button.</p>
<h2>Wardrobe Electrical Planning</h2>
<p>Wardrobes are increasingly fitted with internal lighting, charging drawers, and even small vanity mirror lights. These provisions must be made before the wardrobe is installed: wiring behind an installed wardrobe is nearly impossible.</p>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Provision</th><th>Type</th><th>Location</th><th>Notes</th></tr>
  </thead>
  <tbody>
    <tr><td>Interior Sensor Light</td><td>LED strip / puck light (12V)</td><td>Top rail of each section</td><td>Door-open sensor trigger; needs driver outside</td></tr>
    <tr><td>Charging Drawer Socket</td><td>5A socket or USB outlet</td><td>In dedicated drawer unit</td><td>For phone/tablet overnight charging inside wardrobe</td></tr>
    <tr><td>Vanity Mirror Light</td><td>LED strip around mirror</td><td>Dressing area side</td><td>CRI 90+ for true skin-tone rendering</td></tr>
    <tr><td>Safe Socket</td><td>5A</td><td>Behind locker unit</td><td>For biometric safe charging</td></tr>
    <tr><td>External Switchboard</td><td>1-way switch</td><td>Outside wardrobe, 1,200mm</td><td>For manually switching wardrobe lights</td></tr>
  </tbody>
</table>
</div>
<h2>Study Room / Home Office Electrical Planning</h2>
<p><strong>Study / Home Office: 10–16 points</strong></p>
<div class="table-wrap">
<table>
  <thead><tr><th>Point</th><th>Where and why</th></tr></thead>
  <tbody>
    <tr><td>Desk Sockets (×4 min)</td><td>At desk height 750mm: laptop, monitor, lamp, hub</td></tr>
    <tr><td>Dedicated UPS Circuit</td><td>For computer and NAS: must not trip on inverter changeover</td></tr>
    <tr><td>LAN / Network Point (×2)</td><td>Desk level: wired network is faster than Wi-Fi for WFH</td></tr>
    <tr><td>Printer Socket</td><td>Near printer location, floor level or sideboard</td></tr>
    <tr><td>Desk Lamp Socket</td><td>5A at desk level, ideally USB+socket combo</td></tr>
    <tr><td>Task Lighting (Under Shelf)</td><td>LED strip below bookshelf illuminating desk surface</td></tr>
    <tr><td>AC Point</td><td>16A dedicated if dedicated study room</td></tr>
    <tr><td>Video Call Backdrop Light</td><td>Soft light behind monitor for video conferencing</td></tr>
  </tbody>
</table>
</div>
<h2>Children's Room Electrical Planning</h2>
<p>Children's room electrical planning demands extra safety provisions beyond standard. All sockets must have <strong>child safety shutters</strong>, socket heights should be higher than standard (at adult switchboard height), and nightlight provisions are essential.</p>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Point</th><th>Special Requirement</th><th>Safety Note</th></tr>
  </thead>
  <tbody>
    <tr><td>All Sockets</td><td>Child safety shutter (CSP) type only</td><td>ISI marked: mandatory for children's rooms</td></tr>
    <tr><td>Socket Height</td><td>Minimum 1,200mm from FFL</td><td>Out of toddler reach: same height as switchboard</td></tr>
    <tr><td>Nightlight Socket</td><td>5A at 300mm: bedside</td><td>Plug-in nightlight for nighttime safety</td></tr>
    <tr><td>Study Desk Sockets (×3)</td><td>At desk level 750mm</td><td>For tablet, laptop, study lamp</td></tr>
    <tr><td>AC Point</td><td>16A, 2,000mm FFL</td><td>Timer provision recommended: auto-off at night</td></tr>
    <tr><td>Ceiling Fan</td><td>5-speed electronic regulator</td><td>Low speed for infant rooms</td></tr>
    <tr><td>Night Light / Sleep Light</td><td>In-built in switch plate or plug-in</td><td>Warm white 2,700K, max 5W</td></tr>
    <tr><td>Toy Charging Socket</td><td>USB+5A combo near play area</td><td>1,200mm height: RCCB protected circuit</td></tr>
  </tbody>
</table>
</div>
<h2>Dining Area Electrical Planning</h2>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Point</th><th>Qty</th><th>Height / Position</th><th>Purpose</th></tr>
  </thead>
  <tbody>
    <tr><td>Pendant / Chandelier</td><td>1–3</td><td>Above dining table centre, 700mm above table</td><td>Task + ambience lighting</td></tr>
    <tr><td>Dimmer Switch</td><td>1</td><td>1,200mm near entry</td><td>Mood lighting control for dining</td></tr>
    <tr><td>Bar Unit / Sideboard Socket</td><td>2–3</td><td>900mm near bar</td><td>Mini bar, electric wine chiller, coffee machine</td></tr>
    <tr><td>Buffet / Crockery Light</td><td>1–2</td><td>Inside display cabinet</td><td>LED strip inside glass cabinet</td></tr>
    <tr><td>Floor Socket (if large table)</td><td>1</td><td>Floor level, covered</td><td>Centre-table charging for extended dinner parties</td></tr>
    <tr><td>Cove Light (if false ceiling)</td><td>Per design</td><td>In ceiling cove</td><td>Warm wash light for dining experience</td></tr>
  </tbody>
</table>
</div>
<h2>Pooja Room Electrical Planning</h2>
<p>The pooja room, despite being compact, needs thoughtful electrical planning. Devotional LED strips, lamp sockets, bell mechanisms, and even speaker provisions for chants are increasingly part of contemporary pooja room design.</p>
<p><strong>Pooja Room: 6–10 points</strong></p>
<div class="table-wrap">
<table>
  <thead><tr><th>Point</th><th>Where and why</th></tr></thead>
  <tbody>
    <tr><td>Deity Backdrop LED Strip</td><td>Warm gold LED behind idol frame, 2,700–3,000K</td></tr>
    <tr><td>Electric Lamp Socket</td><td>For diyas / electric deepam: 5A below idol platform</td></tr>
    <tr><td>Ceiling Downlight</td><td>1–2 warm downlights, 2,700K, not cool white</td></tr>
    <tr><td>Speaker / Music Socket</td><td>For bhajan speaker: 5A near shelf</td></tr>
    <tr><td>Bell / Chime</td><td>Electric bell provision at pooja entrance</td></tr>
    <tr><td>Agarbatti / Incense Fan</td><td>Small exhaust fan provision at top of pooja room</td></tr>
    <tr><td>Profile Lighting (Frame)</td><td>LED strips around the pooja unit frame/arch</td></tr>
    <tr><td>Timer Switch</td><td>Auto on/off for electric lamps at puja time</td></tr>
  </tbody>
</table>
</div>
<h2>Balcony Electrical Planning</h2>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Point</th><th>IP Rating Required</th><th>Notes</th></tr>
  </thead>
  <tbody>
    <tr><td>Ceiling Light (outdoor)</td><td>IP44 minimum</td><td>Weatherproof, not standard indoor downlight</td></tr>
    <tr><td>Wall Socket (weatherproof)</td><td>IP44 with cover flap</td><td>For phone charging, small fan, fairy lights</td></tr>
    <tr><td>Garden / Planter Lighting</td><td>IP65 (direct exposure)</td><td>Low-voltage garden spots or LED strips in planters</td></tr>
    <tr><td>Exhaust Fan Provision</td><td>N/A (open balcony)</td><td>Only if enclosed/semi-enclosed balcony</td></tr>
    <tr><td>CCTV Power Point</td><td>IP44 with cover</td><td>Near camera mounting position on balcony ceiling</td></tr>
    <tr><td>Festoon / Party Lights</td><td>IP44</td><td>Dedicated socket for string lights / event lighting</td></tr>
  </tbody>
</table>
</div>
<h2>Utility Area Electrical Planning</h2>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Appliance / Point</th><th>Circuit Type</th><th>Special Provision</th></tr>
  </thead>
  <tbody>
    <tr><td>Washing Machine</td><td>16A Dedicated</td><td>With isolation valve provision nearby</td></tr>
    <tr><td>Dryer (Electric)</td><td>16A Dedicated</td><td>High draw: separate MCB, check load</td></tr>
    <tr><td>Iron Box Socket</td><td>16A</td><td>Folding ironing board height: 900–1,000mm</td></tr>
    <tr><td>Vacuum Cleaner Socket</td><td>5A or 16A</td><td>At 300mm floor level for easy reach</td></tr>
    <tr><td>Utility Light</td><td>5A circuit</td><td>Bright white light: functional space</td></tr>
    <tr><td>Inverter Battery Room</td><td>Heavy-duty</td><td>Ventilated: no sealed spaces for battery gases</td></tr>
  </tbody>
</table>
</div>
<h2>Bathroom Electrical Planning</h2>
<p>Bathroom electrical is governed by strict safety zones (IP ratings, zone classifications). Every bathroom point must follow IS 3646 / IEC 60364-7-701. No compromises on safety here.</p>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Point</th><th>Zone</th><th>IP Rating</th><th>Note</th></tr>
  </thead>
  <tbody>
    <tr><td>Ceiling Light</td><td>Zone 1</td><td>IP44 minimum</td><td>No pendant lights: flush or recessed only</td></tr>
    <tr><td>Exhaust Fan</td><td>Zone 2</td><td>IP44</td><td>Near ceiling on outer wall, humidistat option</td></tr>
    <tr><td>Geyser Point (16A)</td><td>Outside zone</td><td>Standard</td><td>Switch outside bathroom, NEVER inside</td></tr>
    <tr><td>Shaver Socket (SELV)</td><td>Zone 2</td><td>IP44</td><td>Must be SELV isolation transformer type</td></tr>
    <tr><td>Mirror Light</td><td>Zone 2</td><td>IP44</td><td>LED strip around mirror: IP-rated driver</td></tr>
    <tr><td>Bathroom Heater</td><td>Zone 2</td><td>IP44</td><td>Only fan-type heaters: no exposed element</td></tr>
    <tr><td>Waterfall / Sensor Tap</td><td>Zone 1</td><td>IP67</td><td>Low-voltage sensor circuit: pre-plan cable route</td></tr>
  </tbody>
</table>
</div>
<div class="callout callout--warn"><span class="callout__title">Watch out</span>⚠️ Bathroom Safety Absolutes<br><br>1. <strong>Geyser switch must be OUTSIDE the bathroom:</strong> never inside. 2. All bathroom circuits must be on <strong>30mA RCCB protection</strong>. 3. No standard sockets inside bathrooms except SELV shaver sockets. 4. Metal conduits and exposed conductive parts must be bonded to earth. 5. <strong>NEVER use extension cords in bathrooms.</strong></div>
<h2>AC Electrical Planning</h2>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>AC Tonnage</th><th>Circuit Required</th><th>Wire Size</th><th>MCB Rating</th><th>Key Notes</th></tr>
  </thead>
  <tbody>
    <tr><td>1 Ton (3-star)</td><td>16A Dedicated</td><td>2.5 sq mm</td><td>16A</td><td>Separate circuit from lighting</td></tr>
    <tr><td>1.5 Ton (5-star Inverter)</td><td>16A Dedicated</td><td>2.5 sq mm</td><td>20A</td><td>Inverter AC has soft start. Still needs dedicated line</td></tr>
    <tr><td>2 Ton</td><td>20A Dedicated</td><td>4 sq mm</td><td>25A</td><td>Higher load: heavier cable mandatory</td></tr>
    <tr><td>Cassette / Ducted</td><td>20–32A</td><td>4–6 sq mm</td><td>Per design</td><td>Commercial type: consult AC installer before electrical rough-in</td></tr>
  </tbody>
</table>
</div>
<h3>AC Electrical Checklist</h3>
<ul>
  <li>Plan AC point location AFTER deciding the indoor unit wall and height</li>
  <li>Outdoor unit side: plan 30A weatherproof socket at ground level for outdoor unit power</li>
  <li>Lay <strong>25mm diameter conduit sleeve through the wall</strong> for refrigerant pipes, before plastering</li>
  <li>Every AC unit needs its own MCB in the distribution board</li>
  <li>AC circuits should not be on the inverter circuit (AC draws too much for inverter backup)</li>
  <li>If installing multiple ACs, plan sub-DB near AC cluster to reduce long cable runs</li>
</ul>
<h2>Geyser Electrical Planning</h2>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Geyser Type</th><th>Capacity</th><th>Circuit</th><th>Switch Position</th><th>Notes</th></tr>
  </thead>
  <tbody>
    <tr><td>Storage Geyser</td><td>10–25L</td><td>16A Dedicated</td><td>Outside bathroom, 1,200mm</td><td>Timer switch recommended: saves energy</td></tr>
    <tr><td>Instant Geyser</td><td>3–6L</td><td>16A Dedicated</td><td>Outside bathroom</td><td>Higher wattage (3–4.5kW): check cable rating</td></tr>
    <tr><td>Central Geyser (whole home)</td><td>35–50L</td><td>32A Dedicated</td><td>Utility room</td><td>Sub-DB recommended near geyser room</td></tr>
    <tr><td>Gas Geyser (electric ignition)</td><td>N/A</td><td>5A</td><td>Near unit</td><td>Only ignition needs power: minimal load</td></tr>
    <tr><td>Heat Pump Water Heater</td><td>100–200L</td><td>20A Dedicated</td><td>Outdoor unit area</td><td>Most energy-efficient: plan outdoor space</td></tr>
  </tbody>
</table>
</div>
<h2>Smart Home Electrical Planning</h2>
<p>Smart home technology requires infrastructure that looks invisible but runs throughout your home. The time to plan smart home wiring is during rough-in: retrofitting smart home infrastructure in a completed interior is expensive and disruptive.</p>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Smart Feature</th><th>Wiring Required</th><th>When to Install</th><th>Cost to Retrofit</th></tr>
  </thead>
  <tbody>
    <tr><td>Smart Switches (WiFi)</td><td>Neutral wire at every switch</td><td>Rough-in phase: most Indian switches lack neutral</td><td>₹800–3,000 per switch</td></tr>
    <tr><td>Smart Lighting (DMX/DALI)</td><td>Control bus cable</td><td>With electrical rough-in</td><td>₹5,000–15,000/room</td></tr>
    <tr><td>Voice Control Hub</td><td>Power + LAN near hub</td><td>Before false ceiling</td><td>Moderate</td></tr>
    <tr><td>Smart Curtain Motor</td><td>Power + control wire in curtain track</td><td>Before false ceiling / pelmet</td><td>₹3,000–8,000/window</td></tr>
    <tr><td>Smart Doorbell / VDP</td><td>Low voltage 2-wire + power</td><td>During rough-in</td><td>Low</td></tr>
    <tr><td>IR / RF Blaster</td><td>Power near media centre</td><td>Anytime</td><td>Negligible</td></tr>
    <tr><td>Smart Locks</td><td>Power at door frame (12V)</td><td>During rough-in</td><td>₹4,000–12,000/door</td></tr>
  </tbody>
</table>
</div>
<p><strong>The Neutral Wire Issue</strong></p>
<p>Most Indian homes use <strong>2-wire switching (Line + Load only)</strong>. Smart switches from brands like Legrand, Schneider, Wipro Smart, and Anchor Panasonic require a <strong>3-wire system (Line + Neutral + Load)</strong>. If you ever plan to upgrade to smart switches, instruct your electrician to <strong>pull neutral wire to every switchboard</strong> during rough-in, at zero additional cost. Not doing this means rework of ₹800–3,000 per switch point later.</p>
<h2>Home Automation Wiring Requirements</h2>
<p><strong>Automation Infrastructure Cables</strong></p>
<ul>
  <li><strong>CAT6 LAN Cable:</strong> Every room, 2 points minimum</li>
  <li><strong>Co-axial (RG6):</strong> TV points for DTH / cable</li>
  <li><strong>RS485 / KNX Bus:</strong> For DALI/KNX lighting control</li>
  <li><strong>4-core speaker cable:</strong> In-wall speakers, room-by-room</li>
  <li><strong>2-core alarm cable:</strong> Door sensors, motion detectors</li>
  <li><strong>Video doorphone cable (6-core):</strong> Door to monitor location</li>
  <li><strong>HDMI conduit sleeves:</strong> From AV rack to every screen</li>
</ul>
<p><strong>Smart Panel / AV Rack Requirements</strong></p>
<ul>
  <li>Dedicated ventilated AV rack space, usually in utility or false ceiling</li>
  <li>Rack power: 6–10 sockets on UPS protected circuit</li>
  <li>LAN patch panel to consolidate all CAT6 runs</li>
  <li>Internet router / mesh hub location, central flat position</li>
  <li>Automation controller (Crestron, C-Bus, Hager, etc.) housing</li>
  <li>All racks need cooling. Plan for ventilation or small fan</li>
</ul>
<h2>Inverter &amp; UPS Planning</h2>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Inverter Type</th><th>Typical Capacity</th><th>What It Backs Up</th><th>Wiring Requirement</th></tr>
  </thead>
  <tbody>
    <tr><td>Standard Home Inverter</td><td>800VA–2kVA</td><td>Fans, lights, one AC (not usually)</td><td>Separate inverter circuit from DB, 4mm² cable</td></tr>
    <tr><td>Solar Inverter (Off-grid)</td><td>2–10kW</td><td>Full home on solar</td><td>Dedicated solar DB + battery bank room</td></tr>
    <tr><td>Online UPS (Computer)</td><td>600VA–3kVA</td><td>Computers, NAS, modems</td><td>Dedicated UPS circuit at each desk</td></tr>
    <tr><td>Li-Ion Home Battery</td><td>5–15kWh</td><td>Full home overnight</td><td>Heavy-duty 3-phase or single-phase DB integration</td></tr>
  </tbody>
</table>
</div>
<h3>Inverter Planning Essentials</h3>
<ul>
  <li>Decide inverter load list BEFORE wiring: determines which circuits go on inverter bus</li>
  <li>Plan <strong>2 separate buses in your DB:</strong> inverter load bus and non-inverter bus</li>
  <li>Battery room or inverter housing must be <strong>ventilated:</strong> battery off-gassing is a fire hazard in sealed spaces</li>
  <li>Inverter cable from battery to inverter must be minimum 25mm² copper: short run, heavy cable</li>
  <li>Plan for future solar integration: lay conduit for solar panel cables on terrace to DB at rough-in</li>
  <li>Never put AC compressors or geysers on inverter circuit: they'll drain the battery in minutes</li>
</ul>
<h2>Generator Backup Planning</h2>
<p><strong>Generator Wiring Requirements</strong></p>
<p>If you plan a DG set (diesel generator) or petrol generator for full-home backup, your electrical plan must include: <strong>Automatic Transfer Switch (ATS)</strong> to switch between EB and DG without manual intervention · Dedicated <strong>heavy-duty outdoor socket</strong> for portable generator connection · <strong>Interlock mechanism</strong> that prevents simultaneous connection of EB and DG (mandatory safety) · Sufficient <strong>cable sizing</strong> from generator to DB based on generator kVA rating.</p>
<h2>Internet &amp; Networking Points</h2>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Room</th><th>LAN Points</th><th>Wi-Fi AP Point</th><th>Notes</th></tr>
  </thead>
  <tbody>
    <tr><td>Living Room / TV Area</td><td>2 CAT6</td><td>1 (ceiling)</td><td>Smart TV + gaming console on wired LAN</td></tr>
    <tr><td>Master Bedroom</td><td>1 CAT6</td><td>1 (ceiling)</td><td>Streaming + smart home hub</td></tr>
    <tr><td>Study / Home Office</td><td>2–3 CAT6</td><td>Optional</td><td>Wired for faster, more stable connection</td></tr>
    <tr><td>Kitchen</td><td>1 CAT6</td><td>Optional</td><td>For smart fridge / smart display</td></tr>
    <tr><td>Main Entry / Lobby</td><td>1 CAT6</td><td>1 (ceiling)</td><td>For video doorphone + access control</td></tr>
    <tr><td>Utility / AV Rack</td><td>Patch panel consolidation</td><td>N/A</td><td>All cables home-run to central patch panel</td></tr>
  </tbody>
</table>
</div>
<p><strong>Future-Proofing Tip</strong></p>
<p>Run <strong>CAT6 or CAT6A cable</strong> (not CAT5e). It supports 10Gbps and is future-ready. Always use <strong>star topology</strong> (every point home-runs to a central patch panel) rather than daisy-chaining. This costs minimally more in cable but gives you complete flexibility to reconfigure the network at any time without re-wiring.</p>
<h2>CCTV Planning</h2>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Camera Location</th><th>Cable Type</th><th>Power</th><th>Coverage</th></tr>
  </thead>
  <tbody>
    <tr><td>Main Door (exterior)</td><td>CAT6 (IP) or co-ax (analog)</td><td>POE or 12V adapter</td><td>Entire entry approach</td></tr>
    <tr><td>Living Room</td><td>CAT6 or RG59</td><td>POE preferred</td><td>Wide-angle: covers whole room</td></tr>
    <tr><td>Parking / Garage</td><td>CAT6 (IP)</td><td>POE</td><td>Number plate readable: 2MP minimum</td></tr>
    <tr><td>Terrace / Balcony</td><td>CAT6, IP-rated camera</td><td>POE</td><td>Perimeter surveillance</td></tr>
    <tr><td>Lift Lobby (if villa)</td><td>CAT6</td><td>POE</td><td>Common area coverage</td></tr>
    <tr><td>NVR / DVR Location</td><td>CAT6 home-run</td><td>UPS backed</td><td>Utility room / AV rack, ventilated</td></tr>
  </tbody>
</table>
</div>
<p><strong>CCTV Planning Rule</strong></p>
<p>All CCTV cables must be <strong>laid in conduits before false ceiling and wall plaster</strong>. IP-based CCTV (using POE switches) is strongly recommended over analog coaxial: single CAT6 cable carries both video and power, simplifying installation dramatically. Plan for <strong>NVR storage on UPS</strong> so footage continues during power cuts, the most critical period for security.</p>
<h2>Security Systems Planning</h2>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>System</th><th>Cable / Signal</th><th>Control Panel Location</th><th>Provision Needed</th></tr>
  </thead>
  <tbody>
    <tr><td>Burglar Alarm (PIR sensors)</td><td>2-core alarm cable</td><td>Main entrance / utility</td><td>Sensor in each room corner at 2,000mm</td></tr>
    <tr><td>Door Magnetic Sensors</td><td>2-core alarm cable</td><td>Via alarm panel</td><td>At each entry door: main + service</td></tr>
    <tr><td>Glass Break Sensors</td><td>2-core alarm cable</td><td>Via alarm panel</td><td>Near large windows / glass facades</td></tr>
    <tr><td>Smoke Detectors</td><td>2-core + power or wireless</td><td>Ceiling of each room</td><td>Mandatory in kitchen and all bedrooms</td></tr>
    <tr><td>CO Detector</td><td>Power only (mains)</td><td>Near gas appliances</td><td>Mandatory if gas cooking / gas geyser</td></tr>
    <tr><td>Water Leak Sensor</td><td>Low voltage</td><td>Under kitchen sink, WM area</td><td>Catch leaks before damage</td></tr>
    <tr><td>Panic Button</td><td>2-core to alarm panel</td><td>Master bedroom, elderly room</td><td>Silent alarm trigger: concealed</td></tr>
  </tbody>
</table>
</div>
<h2>Door Bell &amp; Video Door Phone Planning</h2>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>System Type</th><th>Wiring</th><th>Monitor Location</th><th>Notes</th></tr>
  </thead>
  <tbody>
    <tr><td>Simple Door Bell</td><td>2-core, 8–12V</td><td>Chime unit on wall, 1,500mm</td><td>Transformer near chime; bell push at door</td></tr>
    <tr><td>Video Door Phone (wired)</td><td>6-core video cable</td><td>Living room, kitchen: 1,400mm</td><td>Lay cable from main door to monitor point before plastering</td></tr>
    <tr><td>Wi-Fi Video Doorbell</td><td>Power only (2-core 8V AC)</td><td>App-based: no separate monitor</td><td>Needs power at door: plan during rough-in</td></tr>
    <tr><td>Multi-Apartment (video intercom)</td><td>CAT5/6 bus</td><td>Each flat + security desk</td><td>Builder provision: verify existing infrastructure</td></tr>
    <tr><td>Smart Lock Integration</td><td>12V DC + data</td><td>VDP screen unlocks door</td><td>Plan 12V power at door frame for electric lock strike</td></tr>
  </tbody>
</table>
</div>
<h2>Electrical Safety Guidelines</h2>
<p>Safety is not optional in residential electrical work. Every safety device listed below is mandatory, not advisory.</p>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Safety Device</th><th>Where Required</th><th>Why Critical</th></tr>
  </thead>
  <tbody>
    <tr><td>RCCB (Residual Current Circuit Breaker)</td><td>All bathroom &amp; kitchen circuits</td><td>Trips in 30ms on earth leakage, prevents electrocution</td></tr>
    <tr><td>MCB (Miniature Circuit Breaker)</td><td>Every individual circuit</td><td>Overcurrent protection: replaces fuses</td></tr>
    <tr><td>RCBO (Combined RCCB+MCB)</td><td>Critical circuits</td><td>Dual protection in one device</td></tr>
    <tr><td>Surge Protection Device (SPD)</td><td>Main DB + AV equipment</td><td>Protects against lightning transients and grid surges</td></tr>
    <tr><td>Earth Leakage Protection</td><td>Whole home DB</td><td>System-level protection against leakage</td></tr>
    <tr><td>Proper Earthing (3-pin)</td><td>All power sockets</td><td>Fault current path: prevents shock from faulty appliances</td></tr>
    <tr><td>Child Safety Shutters</td><td>All sockets in children's rooms</td><td>Prevents insertion of objects by children</td></tr>
    <tr><td>ISI-Marked Wires &amp; Devices</td><td>Entire installation</td><td>Quality assurance: substandard wires cause fires</td></tr>
  </tbody>
</table>
</div>
<div class="callout callout--warn"><span class="callout__title">Watch out</span>⚠️ Earthing: The Most Neglected Safety Element<br><br>Earthing failures cause the majority of electrical fatalities in Indian homes. Insist on a <strong>proper earthing electrode:</strong> not just a green wire that goes nowhere. Test earthing resistance: it must be <strong>below 5 ohms</strong> (ideally below 1 ohm). All metallic enclosures, water pipes, and equipment frames must be bonded to earth. Test annually.</div>
<h2>Common Electrical Mistakes in Home Interiors</h2>
<p><strong>Planning Mistakes</strong></p>
<ul>
  <li>Starting electrical work before interior layout is finalised</li>
  <li>Not planning for neutral wire at switchboards</li>
  <li>Forgetting appliance-specific provisions (chimney, dishwasher)</li>
  <li>Ignoring future provisions (EV charger, solar, home automation)</li>
  <li>No separate circuits for lights and power</li>
  <li>Under-sizing the main distribution board (too few ways)</li>
  <li>No CCTV or network cable planning, retrofitting is costly</li>
</ul>
<p><strong>Execution Mistakes</strong></p>
<ul>
  <li>Using substandard / non-ISI wire and conduits</li>
  <li>Joints inside walls (all joints must be in junction boxes)</li>
  <li>No RCCB on bathroom / kitchen circuits</li>
  <li>Switch heights inconsistent across rooms</li>
  <li>AC pipe sleeve not laid before wall plaster</li>
  <li>Geyser switch inside bathroom</li>
  <li>Using aluminum wiring for internal circuits</li>
  <li>No earthing testing before occupation</li>
</ul>
<h2>Electrical Cost Estimation</h2>
<p>Electrical work in Indian homes is typically quoted either per-point or as a lump-sum. Here are 2025 benchmark rates for reference across apartment types.</p>
<div class="table-wrap">
<table>
  <thead>
    <tr><th>Work Item</th><th>Unit</th><th>Budget Range</th><th>Mid-Range</th><th>Premium</th></tr>
  </thead>
  <tbody>
    <tr><td>Electrical Point (concealed)</td><td>Per point</td><td>₹800–1,200</td><td>₹1,500–2,500</td><td>₹3,000–5,000</td></tr>
    <tr><td>Distribution Board (8-way)</td><td>Per DB</td><td>₹4,000–6,000</td><td>₹8,000–15,000</td><td>₹20,000–40,000</td></tr>
    <tr><td>Modular Switch Plate</td><td>Per module</td><td>₹80–150</td><td>₹200–450</td><td>₹600–2,000</td></tr>
    <tr><td>MCB (per unit)</td><td>Per MCB</td><td>₹150–250</td><td>₹350–600</td><td>₹800–1,800</td></tr>
    <tr><td>RCCB (per unit)</td><td>Per RCCB</td><td>₹800–1,500</td><td>₹2,000–4,000</td><td>₹5,000–10,000</td></tr>
    <tr><td>Full 2BHK Electrical</td><td>Turnkey</td><td>₹45,000–70,000</td><td>₹80,000–1,40,000</td><td>₹1,60,000–2,80,000</td></tr>
    <tr><td>Full 3BHK Electrical</td><td>Turnkey</td><td>₹65,000–1,00,000</td><td>₹1,20,000–2,00,000</td><td>₹2,50,000–4,00,000</td></tr>
    <tr><td>Smart Home Wiring (add-on)</td><td>Per home</td><td>₹30,000–60,000</td><td>₹80,000–1,50,000</td><td>₹2,00,000–5,00,000</td></tr>
    <tr><td>CCTV System (4 cameras)</td><td>Turnkey</td><td>₹18,000–28,000</td><td>₹35,000–65,000</td><td>₹80,000–1,50,000</td></tr>
  </tbody>
</table>
</div>
<p><strong>Never Cut Budget on Electrical</strong></p>
<p>Electrical is the one category in a home interior where <strong>saving money creates permanent risk</strong>. A ₹20,000 saving on wire quality or fewer MCBs can result in a ₹5-lakh fire loss or worse. Use <strong>ISI-marked FR (fire-retardant) copper wire</strong> throughout, name-brand MCBs (Schneider, Legrand, Havells, ABB), and <strong>never compromise on earthing and RCCB</strong>.</p>
<h2>Final Electrical Checklist Before Interior Work</h2>
<p>Use this interactive checklist during your electrical planning review. Click each item to mark it complete. Print or screenshot before sharing with your electrician.</p>
<p><strong>Planning &amp; Drawing</strong></p>
<p>Interior layout and furniture plan 100% finalised before electrical drawing</p>
<p>Dimensioned electrical drawing prepared by licensed electrician / consultant</p>
<p><strong>All appliance positions confirmed and marked on drawing</strong></p>
<p>Load calculation done: DB sizing confirmed (minimum 20% spare capacity)</p>
<p>Separate circuits planned: lights, power, kitchen, AC, geyser, inverter bus</p>
<ul>
  <li>Neutral wire planned at all switchboard locations</li>
  <li>Smart home / automation provisions included in drawing</li>
  <li>CCTV, network, and security cable routes planned</li>
  <li>Modular Kitchen Points</li>
</ul>
<p>Chimney: 16A dedicated, at 1,800mm above hob, hidden in cabinet cavity</p>
<ul>
  <li><strong>Refrigerator:</strong> 16A dedicated, floor level, individual MCB</li>
  <li><strong>Microwave:</strong> 16A dedicated in tall/upper unit at 1,500mm</li>
  <li><strong>Oven:</strong> 16A dedicated, separate from microwave</li>
  <li><strong>Dishwasher:</strong> 16A dedicated with water provision</li>
  <li><strong>RO Water Purifier:</strong> 5A under sink</li>
  <li><strong>Counter sockets:</strong> minimum 4–6, at 1,050mm height</li>
  <li>Under-cabinet LED strip provision</li>
  <li><strong>Exhaust fan:</strong> on outer wall, 2,100mm, separate switch</li>
  <li>Bedroom Points</li>
  <li><strong>Bedside sockets confirmed:</strong> left and right of bed, 650–700mm FFL</li>
  <li>2-way switching for main light (door + bedside)</li>
  <li><strong>AC point:</strong> 16A at 2,000mm FFL, near indoor unit</li>
</ul>
<p>Wardrobe light provision: conduit inside wardrobe zone before installation</p>
<ul>
  <li>Dressing table socket confirmed</li>
  <li>Cove light provision if false ceiling planned</li>
  <li>Bathroom &amp; Geyser</li>
  <li>Geyser switch OUTSIDE bathroom: confirmed position</li>
  <li><strong>All bathroom circuits on 30m:</strong> A RCCB</li>
  <li><strong>Ceiling light:</strong> IP44 rated only</li>
  <li>Exhaust fan on separate switch from light</li>
  <li>Mirror light provision (if vanity mirror planned)</li>
  <li>No standard sockets inside bathroom: shaver socket only (SELV)</li>
  <li>AC, Inverter &amp; Heavy Loads</li>
  <li>Every AC unit has its own dedicated 16A+ circuit and MCB</li>
</ul>
<p>AC pipe sleeves (25mm conduit) laid through walls before plastering</p>
<ul>
  <li>Inverter bus and non-inverter bus separated in main DB</li>
  <li><strong>Battery room / inverter space:</strong> ventilated, accessible</li>
  <li>Solar conduit provision from terrace to DB (if planned)</li>
  <li>Generator interlock / ATS provision in main DB</li>
  <li>Security, CCTV &amp; Networking</li>
</ul>
<p>CCTV cables (CAT6) laid to all camera positions before ceiling closure</p>
<ul>
  <li><strong>NVR / DVR location identified:</strong> ventilated, on UPS</li>
  <li>CAT6 LAN cables home-run to central patch panel location</li>
  <li>Video doorphone cable laid from main door to monitor location</li>
  <li>Alarm / PIR sensor cables laid to panel location</li>
  <li><strong>Smoke detectors:</strong> planned at kitchen and all bedrooms</li>
  <li>Pooja, Balcony &amp; Special Areas</li>
  <li>Pooja room LED strip provision (warm white, not cool white)</li>
  <li>Electric lamp socket in pooja room</li>
  <li><strong>Balcony light:</strong> IP44 weatherproof fitting planned</li>
  <li><strong>Balcony socket:</strong> IP44 with cover flap</li>
  <li><strong>Utility area:</strong> washing machine 16A dedicated</li>
  <li><strong>Study room:</strong> UPS protected circuit for computers</li>
  <li>Safety &amp; Quality Checks</li>
  <li><strong>All wires:</strong> ISI marked, FR grade, copper only, brand verified</li>
</ul>
<p>RCCB fitted on all wet area circuits (kitchen, bathroom, balcony)</p>
<ul>
  <li>Surge Protection Device (SPD) fitted in main DB</li>
  <li>Earthing electrode installed and tested (below 5 ohms)</li>
  <li><strong>Children's room sockets:</strong> child safety shutter type</li>
  <li>All circuits tested before false ceiling and tiles are installed</li>
</ul>
<p>Electrical completion certificate from licensed electrician obtained</p>
<p><strong>You're Ready to Start</strong></p>
<p>When every item above is checked, your electrical plan is complete and your electrician can begin rough-in with full confidence. <strong>No rework. No surprises. No wall-breaking after interiors.</strong> Share this checklist with your contractor and review it on-site before plastering begins.</p>
<?php require $_SERVER['DOCUMENT_ROOT'] . '/includes/foot.php'; ?>

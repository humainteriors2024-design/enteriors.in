<?php
/* =====================================================================
   BLOG POSTS — the list of every post. One entry per post.

   To add a post:
     1. Add an entry below. The key is the slug = the file name = the URL:
          'sliding-wardrobe-designs'  →  /blogs/sliding-wardrobe-designs.php  →  enteriors.in/blogs/sliding-wardrobe-designs/
     2. Copy _templates/blog-post.php to /blogs/<slug>.php and write the article.
     3. Put the images in /assets/blogs/<folder>/  (hero.jpg|png|webp = main image).

   Required   title, description, category, folder, hero_alt, date
   Optional   location   place the post is about (shown beside the category, used in schema)
              pillar     key of the parent pillar in nav.php, e.g. 'modular-kitchen' — adds the "part of" link
              seo_title  shorter Google title          updated    last edit, YYYY-MM-DD
              author     key from AUTHORS in config    draft      true = visible on staging only
              canonical  '/main/page/' when the post covers a topic that a main guide owns. The post
                         stays readable but is kept out of Google (noindex, follow), the sitemap and
                         llms.txt, so only one page competes for that search. The migrated older
                         versions use this. (config.php → DUPLICATE_TOPIC switches to a canonical tag.)
   Extras such as the quick answer, FAQ and related links are set at the top of the post file itself.
   ===================================================================== */
$POSTS = [

  /* MIGRATED-START — written by tools/migrate.php on 2026-10-04 */
  'kitchen-renovation-cost' => [
    'title'       => 'Kitchen Renovation Cost in India: What You Actually Pay',
    'seo_title'   => 'Kitchen Renovation Cost in India (2026)',
    'description' => 'Kitchen renovation cost in India for 2026: three budget tiers, a full cost and labour breakdown, timeline, costly mistakes and a pre-renovation checklist.',
    'category'    => 'Cost',
    'pillar'      => 'cost',
    'folder'      => 'kitchen-renovation-cost',
    'hero_alt'    => 'Kitchen Renovation Cost in India: What You Actually Pay',
    'date'        => '2026-06-11',
    'updated'     => '2026-10-07',
  ],
  'wallpaper-cost-per-sq-ft' => [
    'title'       => 'Wallpaper Cost per Square Foot in India (2026)',
    'seo_title'   => 'Wallpaper Cost per Sq Ft in India (2026)',
    'description' => 'Wallpaper cost per sq ft in India for 2026: prices by type and brand, installation charges, upkeep, which rooms suit which paper and wallpaper vs paint.',
    'category'    => 'Cost',
    'pillar'      => 'cost',
    'folder'      => 'wallpaper-cost-per-sq-ft',
    'hero_alt'    => 'Wallpaper Cost per Square Foot in India (2026)',
    'date'        => '2026-06-11',
    'updated'     => '2026-10-07',
  ],
  'hidden-costs-home-interiors' => [
    'title'       => 'Hidden Costs in Home Interiors: What Most Homeowners Discover Too Late',
    'seo_title'   => 'Hidden Costs in Home Interiors',
    'description' => 'The hidden costs in home interiors: what quotations leave out, how to read one line by line, real budget examples and how much contingency to keep.',
    'category'    => 'Cost',
    'pillar'      => 'cost',
    'folder'      => 'hidden-costs-home-interiors',
    'hero_alt'    => 'Hidden Costs in Home Interiors: What Most Homeowners Discover Too Late',
    'date'        => '2026-06-19',
    'updated'     => '2026-10-07',
  ],
  '2-bhk-interior-cost-breakdown' => [
    'title'       => '2BHK Interior Design Cost for 800 to 1,500 Sq Ft Homes',
    'seo_title'   => '2BHK Interior Cost by Flat Size',
    'description' => 'What a 2BHK interior costs for 800 to 1,500 sq ft flats: boards and finishes, modular kitchen, wardrobes, flooring, labour and where budgets slip.',
    'category'    => 'Cost',
    'pillar'      => 'cost',
    'folder'      => '2-bhk-interior-cost-breakdown',
    'hero_alt'    => '2BHK Interior Design Cost for 800 to 1,500 Sq Ft Homes',
    'date'        => '2026-06-10',
    'updated'     => '2026-10-07',
    'canonical'   => '/cost/2-bhk-interior-cost/',
  ],
  '3-bhk-interior-budget-planning' => [
    'title'       => '3 BHK Interior Budget Planning Guide',
    'seo_title'   => '3 BHK Interior Budget Planning',
    'description' => 'Plan a 3 BHK interior budget: room-wise cost ranges, material comparisons, sample budgets at three levels and ways to save without cutting quality.',
    'category'    => 'Cost',
    'pillar'      => 'cost',
    'folder'      => '3-bhk-interior-budget-planning',
    'hero_alt'    => '3 BHK Interior Budget Planning Guide',
    'date'        => '2026-06-14',
    'updated'     => '2026-10-07',
    'canonical'   => '/cost/3-bhk-interior-cost/',
  ],
  'acrylic-vs-laminate-complete-comparison' => [
    'title'       => 'Acrylic vs Laminate: Durability, Cost and Upkeep Compared',
    'seo_title'   => 'Acrylic vs Laminate Compared',
    'description' => 'Acrylic vs laminate compared on durability, scratch resistance, cost, cleaning, moisture, UV stability and lifespan, with a verdict for each room.',
    'category'    => 'Materials',
    'pillar'      => 'materials',
    'folder'      => 'acrylic-vs-laminate-complete-comparison',
    'hero_alt'    => 'Acrylic vs Laminate: Durability, Cost and Upkeep Compared',
    'date'        => '2024-01-01',
    'updated'     => '2026-10-07',
    'canonical'   => '/compare/acrylic-vs-laminate/',
  ],
  'interior-material-brands-india' => [
    'title'       => 'Interior Material Brands in India: What Goes Into a Well-Built Home',
    'seo_title'   => 'Interior Material Brands in India (2026)',
    'description' => 'The main interior material brands in India by category: plywood, laminates, hardware, handles, channels, acrylic, wall panels and glass.',
    'category'    => 'Materials',
    'pillar'      => 'materials',
    'folder'      => 'interior-material-brands-india',
    'hero_alt'    => 'Interior Material Brands in India: What Goes Into a Well-Built Home',
    'date'        => '2025-06-11',
    'updated'     => '2026-10-07',
  ],
  'acrylic-finish-benefits-costs' => [
    'title'       => 'Acrylic Finish for Home Interiors: Benefits, Costs and Common Problems',
    'seo_title'   => 'Acrylic Finish for Home Interiors',
    'description' => 'Acrylic finish for kitchens and wardrobes: types, brands, costs, common problems and fixes, and how it compares with laminate, PU, membrane and glass.',
    'category'    => 'Materials',
    'pillar'      => 'materials',
    'folder'      => 'acrylic-finish-benefits-costs',
    'hero_alt'    => 'Acrylic Finish for Home Interiors: Benefits, Costs and Common Problems',
    'date'        => '2026-06-18',
    'updated'     => '2026-10-07',
    'canonical'   => '/materials/acrylic-finish/',
  ],
  'veneer-finish-luxury-wood-guide' => [
    'title'       => 'Veneer Finish for Home Interiors: Species, Cuts, Grades and Cost',
    'seo_title'   => 'Veneer Finish for Home Interiors',
    'description' => 'Veneer for home interiors: wood species, cutting patterns, matching, grades, polish, cost and durability, and how to choose for kitchens and wardrobes.',
    'category'    => 'Materials',
    'pillar'      => 'materials',
    'folder'      => 'veneer-finish-luxury-wood-guide',
    'hero_alt'    => 'Veneer Finish for Home Interiors: Species, Cuts, Grades and Cost',
    'date'        => '2026-06-25',
    'updated'     => '2026-10-07',
    'canonical'   => '/materials/wood-veneer/',
  ],
  'hdhmr-board-carpenter-guide' => [
    'title'       => 'HDHMR Board for Interiors: A Carpenter\'s Guide and When Not to Use It',
    'seo_title'   => 'HDHMR Board: A Carpenter\'s Guide',
    'description' => 'HDHMR board from the workshop side: how it is made, 2026 prices, brands, spotting poor boards, fixing and edge-banding tips, and where not to use it.',
    'category'    => 'Materials',
    'pillar'      => 'materials',
    'folder'      => 'hdhmr-board-carpenter-guide',
    'hero_alt'    => 'HDHMR Board for Interiors: A Carpenter\'s Guide and When Not to Use It',
    'date'        => '2026-06-26',
    'updated'     => '2026-10-07',
    'canonical'   => '/materials/hdhmr-board/',
  ],
  'interior-materials-a-to-z' => [
    'title'       => 'Interior Materials A–Z: A Designer\'s Glossary',
    'seo_title'   => 'Interior Materials A–Z',
    'description' => 'An A–Z of interior design materials, from acoustic panels to zellige tiles, with a short description, typical uses and what to watch for with each.',
    'category'    => 'Materials',
    'pillar'      => 'materials',
    'folder'      => 'interior-materials-a-to-z',
    'hero_alt'    => 'Interior Materials A–Z: A Designer\'s Glossary',
    'date'        => '2026-06-11',
    'updated'     => '2026-10-07',
    'canonical'   => '/glossary/',
  ],
  'l-shape-modular-kitchen-designs' => [
    'title'       => 'L-Shape Modular Kitchen Designs: Colours, Layouts and Space Ideas',
    'seo_title'   => 'L-Shape Modular Kitchen Designs (2026)',
    'description' => 'L-shape modular kitchen designs: 12 colour themes, space-saving layouts, work zones, material options and cost estimates for Indian homes.',
    'category'    => 'Kitchen',
    'pillar'      => 'modular-kitchen',
    'folder'      => 'l-shape-modular-kitchen-designs',
    'hero_alt'    => 'L-Shape Modular Kitchen Designs: Colours, Layouts and Space Ideas',
    'date'        => '2026-06-30',
    'updated'     => '2026-10-07',
  ],
  'u-shape-kitchen-designs' => [
    'title'       => 'U-Shape Kitchen Designs: Workflow, Storage and Sizes',
    'seo_title'   => 'U-Shape Kitchen Designs (2026)',
    'description' => 'U-shape kitchen design for Indian homes: real dimensions, workflow and storage, who it suits, U vs L vs island, ventilation and cost.',
    'category'    => 'Kitchen',
    'pillar'      => 'modular-kitchen',
    'folder'      => 'u-shape-kitchen-designs',
    'hero_alt'    => 'U-Shape Kitchen Designs: Workflow, Storage and Sizes',
    'date'        => '2026-06-30',
    'updated'     => '2026-10-07',
  ],
  'modular-kitchen-planning-guide' => [
    'title'       => 'Modular Kitchen Planning Guide',
    'seo_title'   => 'Modular Kitchen Planning Guide (2026)',
    'description' => 'Plan a modular kitchen step by step: layouts, boards and finishes, counter heights, lighting, ventilation, storage, hardware and the mistakes to avoid.',
    'category'    => 'Kitchen',
    'pillar'      => 'modular-kitchen',
    'folder'      => 'modular-kitchen-planning-guide',
    'hero_alt'    => 'Modular Kitchen Planning Guide',
    'date'        => '2026-06-10',
    'updated'     => '2026-10-07',
    'canonical'   => '/modular-kitchen/',
  ],
  'kitchen-storage-solutions-guide' => [
    'title'       => 'Kitchen Storage Solutions for Every Home and Budget',
    'seo_title'   => 'Kitchen Storage Solutions',
    'description' => 'Kitchen storage planned by zone: cabinet types, drawer systems, corner units, tall units and accessories, with what to choose for your kitchen size and budget.',
    'category'    => 'Kitchen',
    'pillar'      => 'modular-kitchen',
    'folder'      => 'kitchen-storage-solutions-guide',
    'hero_alt'    => 'Kitchen Storage Solutions for Every Home and Budget',
    'date'        => '2026-06-16',
    'updated'     => '2026-10-07',
    'canonical'   => '/modular-kitchen/storage-solutions/',
  ],
  'modular-kitchen-storage-units-explained' => [
    'title'       => 'Modular Kitchen Storage: Every Unit and Accessory, with Costs',
    'seo_title'   => 'Modular Kitchen Storage Units Explained',
    'description' => 'Modular kitchen storage explained: 18 unit and accessory types with 2026 prices, a Hettich, Hafele and Blum comparison and what suits each layout.',
    'category'    => 'Kitchen',
    'pillar'      => 'modular-kitchen',
    'folder'      => 'modular-kitchen-storage-units-explained',
    'hero_alt'    => 'Modular Kitchen Storage: Every Unit and Accessory, with Costs',
    'date'        => '2026-06-27',
    'updated'     => '2026-10-07',
    'canonical'   => '/modular-kitchen/storage-solutions/',
  ],
  'modular-kitchen-colour-pairings' => [
    'title'       => 'Modular Kitchen Colour Combinations: Pairings That Work',
    'seo_title'   => 'Modular Kitchen Colour Combinations',
    'description' => 'Kitchen colour combinations that work: how colour changes the sense of space, which pairings hide daily wear and which suit small kitchens.',
    'category'    => 'Kitchen',
    'pillar'      => 'modular-kitchen',
    'folder'      => 'modular-kitchen-colour-pairings',
    'hero_alt'    => 'Modular Kitchen Colour Combinations: Pairings That Work',
    'date'        => '2026-06-20',
    'updated'     => '2026-10-07',
    'canonical'   => '/blogs/kitchen-colour-combinations/',
  ],
  'two-colour-kitchen-laminates' => [
    'title'       => 'Two-Colour Combinations for Kitchen Laminates That Work in Indian Homes',
    'seo_title'   => 'Two-Colour Kitchen Laminate Combinations',
    'description' => 'Ten two-colour laminate combinations for kitchens, with why each works, where it fails and how to choose by light, kitchen size and cooking style.',
    'category'    => 'Kitchen',
    'pillar'      => 'modular-kitchen',
    'folder'      => 'two-colour-kitchen-laminates',
    'hero_alt'    => 'Two-Colour Combinations for Kitchen Laminates That Work in Indian Homes',
    'date'        => '2026-06-25',
    'updated'     => '2026-10-07',
    'canonical'   => '/blogs/kitchen-colour-combinations/',
  ],
  'japandi-wabi-sabi-meets-scandinavian' => [
    'title'       => 'Japandi Interior Design: Where Japanese Wabi-Sabi Meets Scandinavian Hygge',
    'seo_title'   => 'Japandi Interior Design',
    'description' => 'Japandi interior design explained: the mix of Japanese wabi-sabi and Scandinavian hygge, with colours, furniture, materials, principles and sourcing tips.',
    'category'    => 'Styles',
    'pillar'      => 'styles',
    'folder'      => 'japandi-wabi-sabi-meets-scandinavian',
    'hero_alt'    => 'Japandi Interior Design: Where Japanese Wabi-Sabi Meets Scandinavian Hygge',
    'date'        => '2026-06-20',
    'updated'     => '2026-10-07',
    'canonical'   => '/styles/japandi/',
  ],
  'minimalist-home-design-ideas' => [
    'title'       => 'Minimalist Home Design: A Practical Guide',
    'seo_title'   => 'Minimalist Home Design Ideas',
    'description' => 'Minimalist home design in practice: the thinking behind it, colours, materials, room-by-room ideas, Bangalore costs, upkeep and common mistakes.',
    'category'    => 'Styles',
    'location'    => 'Bangalore',
    'pillar'      => 'styles',
    'folder'      => 'minimalist-home-design-ideas',
    'hero_alt'    => 'Minimalist Home Design: A Practical Guide',
    'date'        => '2026-07-03',
    'updated'     => '2026-10-07',
    'canonical'   => '/styles/minimalist/',
  ],
  'contemporary-living-india' => [
    'title'       => 'Contemporary Living, Designed for India',
    'seo_title'   => 'Contemporary Interior Design for Indian Homes',
    'description' => 'Contemporary interior design for Indian homes: colour palettes, materials, room-by-room tips and ways to bring in Indian craft without clutter.',
    'category'    => 'Styles',
    'pillar'      => 'styles',
    'folder'      => 'contemporary-living-india',
    'hero_alt'    => 'Contemporary Living, Designed for India',
    'date'        => '2026-06-13',
    'updated'     => '2026-10-07',
    'canonical'   => '/styles/contemporary/',
  ],
  'choosing-an-interior-designer-checklist' => [
    'title'       => 'How to Choose an Interior Designer: A Homeowner\'s Checklist',
    'seo_title'   => 'How to Choose an Interior Designer',
    'description' => 'How to choose an interior designer: types of firms, questions to ask, how to compare quotes, warranty terms and the warning signs to walk away from.',
    'category'    => 'Planning',
    'pillar'      => 'planning',
    'folder'      => 'choosing-an-interior-designer-checklist',
    'hero_alt'    => 'How to Choose an Interior Designer: A Homeowner\'s Checklist',
    'date'        => '2026-06-19',
    'updated'     => '2026-10-07',
    'canonical'   => '/planning/how-to-choose-interior-designer/',
  ],
  'vastu-for-home-interiors-room-by-room' => [
    'title'       => 'Vastu for Home Interiors: Room-by-Room Planning',
    'seo_title'   => 'Vastu for Home Interiors, Room by Room',
    'description' => 'Vastu for home interiors, room by room: traditional guidance on directions, placement and colours, with practical options that need no demolition.',
    'category'    => 'Vastu',
    'pillar'      => 'vastu',
    'folder'      => 'vastu-for-home-interiors-room-by-room',
    'hero_alt'    => 'Vastu for Home Interiors: Room-by-Room Planning',
    'date'        => '2026-08-29',
    'updated'     => '2026-10-07',
    'canonical'   => '/vastu/',
  ],
  'best-interior-designers-hyderabad' => [
    'title'       => 'Best Interior Designers in Hyderabad: A Shortlist by Type of Firm',
    'seo_title'   => 'Best Interior Designers in Hyderabad (2026)',
    'description' => 'A guide to Hyderabad\'s interior designers by type: architect-led studios, luxury residential specialists and turnkey firms, with what to check before you sign.',
    'category'    => 'Designers',
    'pillar'      => 'planning',
    'folder'      => 'best-interior-designers-hyderabad',
    'hero_alt'    => 'Best Interior Designers in Hyderabad: A Shortlist by Type of Firm',
    'date'        => '2026-07-02',
    'updated'     => '2026-10-07',
  ],
  'best-interior-designers-pune' => [
    'title'       => 'Best Interior Designers in Pune: A Shortlist by Type of Firm',
    'seo_title'   => 'Best Interior Designers in Pune (2026)',
    'description' => 'A guide to Pune\'s interior designers by type: architect-led studios, factory-backed turnkey firms and boutique specialists, with what to check before you sign.',
    'category'    => 'Designers',
    'pillar'      => 'planning',
    'folder'      => 'best-interior-designers-pune',
    'hero_alt'    => 'Best Interior Designers in Pune: A Shortlist by Type of Firm',
    'date'        => '2026-07-02',
    'updated'     => '2026-10-07',
  ],
  'top-interior-designers-bangalore' => [
    'title'       => 'Interior Designers in Bangalore: 20 Well-Known Firms Compared',
    'seo_title'   => 'Top Interior Designers in Bangalore (2026)',
    'description' => 'Twenty well-known interior design firms in Bangalore, what each is known for and who it suits, plus five checks to make before you sign with anyone.',
    'category'    => 'Designers',
    'location'    => 'Bangalore',
    'pillar'      => 'planning',
    'folder'      => 'top-interior-designers-bangalore',
    'hero_alt'    => 'Interior Designers in Bangalore: 20 Well-Known Firms Compared',
    'date'        => '2026-06-23',
    'updated'     => '2026-10-07',
  ],
  /* MIGRATED-END */

  'kitchen-colour-combinations' => [
    'title'       => 'Two-Colour Kitchen Combinations That Work in Indian Homes',
    'seo_title'   => 'Kitchen Colour Combinations: 10 Two-Tone Ideas',
    'description' => 'Ten two-colour kitchen laminate combinations with swatches and hex codes, a decision table by kitchen size and light, finish advice and the mistakes to avoid.',
    'category'    => 'Kitchen',
    'location'    => 'Bangalore',
    'pillar'      => 'modular-kitchen',
    'folder'      => 'kitchen-colour-combinations',
    'hero_alt'    => 'Two-colour modular kitchen with warm white wall units and walnut base units',
    'date'        => '2026-10-03',
  ],

  /* Examples — copy one, change the slug and details, then create the matching file in /blogs/
  'l-shape-modular-kitchen-designs' => [
    'title'       => 'L-Shape Modular Kitchen Designs',
    'description' => '...',
    'category'    => 'Kitchen',
    'location'    => 'Bangalore',
    'pillar'      => 'modular-kitchen',
    'folder'      => 'l-shape-modular-kitchen-designs',
    'hero_alt'    => 'L-shape modular kitchen design in Bangalore',
    'date'        => '2026-10-03',
  ],
  'sliding-wardrobe-designs' => [
    'title'       => 'Sliding Wardrobe Designs for Bedrooms',
    'description' => '...',
    'category'    => 'Wardrobes',
    'pillar'      => 'wardrobe',
    'folder'      => 'sliding-wardrobe-designs',
    'hero_alt'    => 'Modern sliding wardrobe design for bedroom',
    'date'        => '2026-10-03',
  ],
  'pooja-room-designs' => [
    'title'       => 'Pooja Room Designs for Indian Homes',
    'description' => '...',
    'category'    => 'Pooja Room',
    'pillar'      => 'rooms',
    'folder'      => 'pooja-room-designs',
    'hero_alt'    => 'Wooden pooja room design with jaali doors',
    'date'        => '2026-10-03',
  ],
  */
];

/* ---------- helpers (no need to edit) ---------- */
const BLOG_BASE = '/blogs';
function post_url($slug) { return BLOG_BASE . '/' . $slug . '/'; }

// Posts that have a file and are not drafts (drafts show on staging), newest first.
// Optional filters: category name, pillar key, how many.
function posts($category = null, $pillar = null, $limit = null) {
  global $POSTS;
  $out = [];
  foreach ($POSTS as $slug => $p) {
    if (!is_file(rtrim($_SERVER['DOCUMENT_ROOT'], '/') . BLOG_BASE . '/' . $slug . '.php')) continue;
    if (!empty($p['draft']) && !is_staging()) continue;
    if ($category && strcasecmp($p['category'], $category) !== 0) continue;
    if ($pillar && ($p['pillar'] ?? '') !== $pillar) continue;
    $out[$slug] = $p + ['slug' => $slug, 'url' => post_url($slug)];
  }
  uasort($out, fn($a, $b) => strcmp($b['date'], $a['date']));
  return $limit ? array_slice($out, 0, $limit, true) : $out;
}
